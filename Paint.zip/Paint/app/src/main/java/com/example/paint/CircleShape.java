package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class CircleShape extends Shape2D {

    private int xEnd;
    private int yEnd;
    private boolean fill;
    private double r;

    public CircleShape(int x, int y, String color) {
        super(x, y, color);
        xEnd = x;
        yEnd = y;
        fill = false;
    }

    @Override
    public void updatePoint(int xe, int ye) {
        xEnd = xe;
        yEnd = ye;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas,paint);
        r= Math.sqrt(Math.pow(xEnd-x,2)+Math.pow(yEnd-y,2));
        if(fill == false)
        {
            paint.setStyle(Paint.Style.STROKE);
        }
        else
        {
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
        }
        canvas.drawCircle(x,y,(float)r,paint);
    }

    public  void setFill(boolean fillStyle)
    {
        fill = fillStyle;
    }

    public Double calculArea(){
        double area = Math.PI * r * r;
        return area;
    }
}
