package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class RectShape extends Shape2D {

    private int xEnd;
    private int yEnd;
    private boolean fill;
    public int area;

    public RectShape(int x, int y, String color) {
        super(x, y, color);
        xEnd = x;
        yEnd = y;
        fill = false;
    }

    @Override
    public void updatePoint(int xe, int ye) {
        xEnd = xe;
        yEnd = ye;
    }

   @Override
    public void draw(Canvas canvas, Paint paint) {
       super.draw(canvas, paint);
       if (fill == false) {
           paint.setStyle(Paint.Style.STROKE);
       } else {
           paint.setStyle(Paint.Style.FILL_AND_STROKE);
       }
       canvas.drawRect(x, y, xEnd, yEnd, paint);

   }

    public  void setFill(boolean fillStyle)
    {
        fill = fillStyle;
    }

    public Double calculArea(){
        int firstSide= x-xEnd;
        int secondSide= y-yEnd;

        Double area= (double)firstSide*secondSide;
        return area;
    }
}
